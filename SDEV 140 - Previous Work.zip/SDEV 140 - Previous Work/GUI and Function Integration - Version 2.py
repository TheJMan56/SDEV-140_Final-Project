"""
Author: Justin W Daily
Date written: 03/09/23
Assignment: DailyJustinWFinalProject
Version of Python: 3.11.1

Short Desc: 
"""

import tkinter as tk

outputWindow = tk.Tk()

outputInventory = tk.Text(outputWindow, width=100)
outputInventory.pack()

inputWindow = tk.Tk()

def newFile():
    fileName = inputFileEntry.get()
    newFile = open(fileName, 'w')
    newFile.close()

def openInputFile():
    inventoryDictionary = {}
    fileName = inputFileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    outputInventoryDictionary(inventoryDictionary)
    inputFile.close()

def openOutputFile():
    inventoryDictionary = {}
    fileName = outputFileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    outputInventoryDictionary(inventoryDictionary)
    inputFile.close()

def getFileInventory():
    inventoryDictionary = {}
    fileName = inputFileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    inputFile.close()
    return inventoryDictionary

def sortInventoryDictionary(inventoryDictionary):
    """Produce an inventory dictionary sorted by SKU"""
    sortedInventoryDictionary = {}
    sortedInventorySKUs = list(inventoryDictionary.keys())
    sortedInventorySKUs.sort()
    for key in sortedInventorySKUs:
        sortedInventoryDictionary[key] = inventoryDictionary[key]
    return sortedInventoryDictionary

def outputInventoryDictionary(inventoryDictionary):
    inventorySKUs = list(inventoryDictionary.keys())
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = list(key) + inventoryDictionary[key]
        inventoryItem[0] = str(inventoryItem[0])
        inventoryItem[1] = str(inventoryItem[1])
        inventoryItem[2] = str(inventoryItem[2])
        inventoryItem[3] = float(inventoryItem[3])
        inventoryItem[4] = float(inventoryItem[4])
        inventoryItem[5] = float(inventoryItem[5])
        outputInventory.insert(tk.END, "%-5s%-15s%-15s%-10.2f%-10.2f%-20.2f" % (inventoryItem[0], inventoryItem[1], \
                                                                                inventoryItem[2], inventoryItem[3], \
                                                                                inventoryItem[4], inventoryItem[5]) + "\n")
    totalInventoryValue = calculateTotal(inventoryDictionary)
    outputInventory.insert(tk.END, "%-55s%-20.2f" % ("Total Inventory Value", totalInventoryValue) + "\n")

def calculateTotal(inventoryDictionary):
    totalInventoryValue = 0
    inventorySKUs = list(inventoryDictionary.keys())
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = list(key) + inventoryDictionary[key]
        totalInventoryValue += float(inventoryItem[5])
    return totalInventoryValue

def addToFile():
    inventoryDictionary = getFileInventory()
    inventorySKU = skuEntry.get()
    inventoryName = nameEntry.get()
    inventoryDepartment = departmentEntry.get()
    inventoryQuantity = quantityEntry.get()
    inventoryQuantity = float(inventoryQuantity)
    inventoryPrice = priceEntry.get()
    inventoryPrice = float(inventoryPrice)
    inventoryDictionary = addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice)
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    saveToFile(inventoryDictionary)
    openOutputFile()

def addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice):
    """Add inventory items to the inventory dictionary"""
    inventoryDescriptors = []
    inventoryValue = inventoryQuantity * inventoryPrice
    inventoryDescriptors.append(inventoryName)
    inventoryDescriptors.append(inventoryDepartment)
    inventoryDescriptors.append(inventoryQuantity)
    inventoryDescriptors.append(inventoryPrice)
    inventoryDescriptors.append(inventoryValue)
    inventoryDictionary[inventorySKU] = inventoryDescriptors
    return inventoryDictionary

def saveToFile(inventoryDictionary):
    fileName = outputFileEntry.get()
    outputFile = open(fileName, 'w')
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = list(key) + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                         str(inventoryItem[1]) + " " + \
                         str(inventoryItem[2]) + " " + \
                         str(inventoryItem[3]) + " " + \
                         str(inventoryItem[4]) + " " + \
                         str(inventoryItem[5]) + "\n")
    outputFile.close()

def deleteFromFile():
    inventoryDictionary = getFileInventory()
    inventorySKU = skuEntry.get()
    inventoryDictionary.pop(inventorySKU)
    saveToFile(inventoryDictionary)
    openFile()

def closeProgram():
    """"""

inputFileFrame = tk.Frame(inputWindow)
inputFileFrame.pack()

inputFileLabel = tk.Label(master=inputFileFrame, text="Input File:")
inputFileLabel.pack()

inputFileEntry = tk.Entry(master=inputFileFrame, text="")
inputFileEntry.pack()

outputFileFrame = tk.Frame(inputWindow)
outputFileFrame.pack()

outputFileLabel = tk.Label(master=outputFileFrame, text="Output File:")
outputFileLabel.pack()

outputFileEntry = tk.Entry(master=outputFileFrame, text="")
outputFileEntry.pack()

paddingFrameOne = tk.Frame(inputWindow)
paddingFrameOne.pack()

paddingLabelOne = tk.Label(master=paddingFrameOne, text="", width=40)
paddingLabelOne.pack()

skuLabel = tk.Label(inputWindow, text="SKU:")
skuLabel.pack()

skuEntry = tk.Entry(inputWindow, text="")
skuEntry.pack()

nameLabel = tk.Label(inputWindow, text="Item Name:")
nameLabel.pack()

nameEntry = tk.Entry(inputWindow, text="")
nameEntry.pack()

departmentLabel = tk.Label(inputWindow, text="Department:")
departmentLabel.pack()

departmentEntry = tk.Entry(inputWindow, text="")
departmentEntry.pack()

quantityLabel = tk.Label(inputWindow, text="Quantity:")
quantityLabel.pack()

quantityEntry = tk.Entry(inputWindow, text="")
quantityEntry.pack()

priceLabel = tk.Label(inputWindow, text="Price:")
priceLabel.pack()

priceEntry = tk.Entry(inputWindow, text="")
priceEntry.pack()

paddingFrameTwo = tk.Frame(inputWindow)
paddingFrameTwo.pack()

paddingLabelTwo = tk.Label(master=paddingFrameTwo, text="")
paddingLabelTwo.pack()

newFileButton = tk.Button(inputWindow, text="New File", command=newFile)
newFileButton.pack()

openFileButton = tk.Button(inputWindow, text="Open File", command=openInputFile)
openFileButton.pack()

addToFileButton = tk.Button(inputWindow, text="Add To File", command=addToFile)
addToFileButton.pack()

deleteFromInventoryButton = tk.Button(inputWindow, text="Delete From Inventory", command=deleteFromFile)
deleteFromInventoryButton.pack()

closeButton = tk.Button(inputWindow, text="Close Program", command=closeProgram)
closeButton.pack()

outputWindow.mainloop()
