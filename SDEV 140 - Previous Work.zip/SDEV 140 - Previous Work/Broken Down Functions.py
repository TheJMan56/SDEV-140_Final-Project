def addToFile():
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        isValid = checkEntry()
        if isValid == False:
            entryErrorMessage()
        else:
            inventoryDictionary = getInventoryDictionary()
            inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
            inventoryDictionary = getInventoryItem(inventoryDictionary)
            saveToFile(inventoryDictionary)
            outputInventory(inventoryDictionary)

def checkFile():
    return True

def checkEntry():
    if skuEntry.get() == "":
        return False
    elif nameEntry.get() == "":
        return False
    elif departmentEntry.get() == "":
        return False
    elif quantityEntry.get() == "":
        return False
    elif priceEntry.get() == "":
        return False
    elif type(skuEntry.get()) != str:
        return False
    elif type(nameEntry.get()) != str:
        return False
    elif type(departmentEntry.get()) != str:
        return False
    elif quantityEntry.get().isdigit() == False:
        return False
    elif priceEntry.get().isdigit() == False:
        return False
    elif " " in skuEntry.get():
        return False
    elif " " in nameEntry.get():
        return False
    elif " " in departmentEntry.get():
        return False
    elif " " in quantityEntry.get():
        return False
    elif " " in priceEntry.get():
        return False
    elif len(skuEntry.get()) != 4:
        return False
    elif len(nameEntry.get()) > 13:
        return False
    elif len(departmentEntry.get()) > 13:
        return False
    elif len(quantityEntry.get()) > 15:
        return False
    elif len(priceEntry.get()) > 15:
        return False
    else:
        return True

def fileErrorMessage():
    "Invalid file name"

def entryCheck():
    outputInventory.insert(tk.END, "Invalid input\n"\
                                   "All inventory input fields must be filled\n" + \
                                   "Inventory input must contain zero spaces\n" + \
                                   "SKU must contain four characters\n" + \
                                   "Name must be ten characters or fewer\n" + \
                                   "Department must be ten characters or fewer\n" + \
                                   "Quantity must be digits only\n" + \
                                   "Quantity must be ten digits or fewer\n" + \
                                   "Price must be digits only\n" + \
                                   "Price must be ten digits or fewer\n" + "\n")

def getInventoryDictionary():
    inventoryDictionary = {}
    fileName = fileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    return inventoryDictionary

def sortInventoryDictionary(inventoryDictionary):
    sortedInventoryDictionary = {}
    sortedInventorySKUs = list(inventoryDictionary.keys())
    sortedInventorySKUs.sort()
    for key in sortedInventorySKUs:
        sortedInventoryDictionary[key] = inventoryDictionary[key]
    return sortedInventoryDictionary

def getInventoryItem(inventoryDictionary):
    inventorySKU = skuEntry.get()
    inventoryName = nameEntry.get()
    inventoryDepartment = departmentEntry.get()
    inventoryQuantity = quantityEntry.get()
    inventoryQuantity = float(inventoryQuantity)
    inventoryPrice = priceEntry.get()
    inventoryPrice = float(inventoryPrice)
    inventoryDictionary = addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice)
    return inventoryDictionary

def addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice):
    inventoryDescriptors = []
    inventoryValue = inventoryQuantity * inventoryPrice
    inventoryDescriptors.append(inventoryName)
    inventoryDescriptors.append(inventoryDepartment)
    inventoryDescriptors.append(inventoryQuantity)
    inventoryDescriptors.append(inventoryPrice)
    inventoryDescriptors.append(inventoryValue)
    inventoryDictionary[inventorySKU] = inventoryDescriptors
    return inventoryDictionary

def saveToFile(inventoryDictionary):
    fileName = fileEntry.get()
    outputFile = open(fileName, 'w')
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                         str(inventoryItem[1]) + " " + \
                         str(inventoryItem[2]) + " " + \
                         str(inventoryItem[3]) + " " + \
                         str(inventoryItem[4]) + " " + \
                         str(inventoryItem[5]) + "\n")
    outputFile.close()

def outputInventory(inventoryDictionary):
    inventorySKUs = list(inventoryDictionary.keys())
    outputInventory.insert(tk.END, "%-6s%-15s%-15s%-17s%-17s%-25s" % ("SKU", "Name", "Department", "Quantity", "Price", "Value") +"\n")
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        inventoryItem[0] = str(inventoryItem[0])
        inventoryItem[1] = str(inventoryItem[1])
        inventoryItem[2] = str(inventoryItem[2])
        inventoryItem[3] = float(inventoryItem[3])
        inventoryItem[4] = float(inventoryItem[4])
        inventoryItem[5] = float(inventoryItem[5])
        outputInventory.insert(tk.END, "%-6s%-15s%-15s%-17d%-17d%-25d" % (inventoryItem[0], inventoryItem[1], \
                                                                                inventoryItem[2], inventoryItem[3], \
                                                                                inventoryItem[4], inventoryItem[5]) + "\n")
    totalInventoryValue = calculateTotal(inventoryDictionary)
    outputInventory.insert(tk.END, "%-70s%-25d" % ("Total Inventory Value", totalInventoryValue) + "\n")


def calculateTotal(inventoryDictionary):
    totalInventoryValue = 0
    inventorySKUs = list(inventoryDictionary.keys())
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        totalInventoryValue += float(inventoryItem[5])
    return totalInventoryValue
