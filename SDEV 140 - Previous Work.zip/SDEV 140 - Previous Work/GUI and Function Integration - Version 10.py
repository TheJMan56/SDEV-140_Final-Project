"""
Author: Justin W Daily
Date written: 03/09/23
Assignment: DailyJustinWFinalProject
Version of Python: 3.11.1

Short Desc: This program maintains files for a basic inventory database.  The database has a fixed schema.
The user uses the GUI to create files for storing inventory lists, to copy files for storing inventory lists, to output the inventory
from files that store inventory lists, add inventory items to files that store inventory lists, delete items from files that store
inventory lists, and to close the program.
"""

#Import module for checking file existence
from pathlib import Path

#Import tkinter module for GUI creation
#Import PIL module for integrating images into the GUI
from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk

#Instantiate window for output to user
outputWindow = tk.Tk() #outputWindow act as the source of output to the user
outputWindow.title("Inventory List")

#Instantiate textbox for output to user
#Pack textbox into output window
outputTextBox = tk.Text(outputWindow, width=100) #outputTextBox contains the output to the user
outputTextBox.pack()

#Intantiate window for input from user
inputWindow = tk.Tk() #inputWindow contains the widgets for user input
inputWindow.title("Inventory Manager")

#Define functions that are attached to buttons in input window

#Check for main file name validity with checkFile function
#Use decision for correct responses to validity check
#If the validity check has failed, output an error message
#Use fileErrorMessage for error message
#If the validity check has passed, use user input from file entry field
#Create a new file with user input value by opening the file with 'w'
#Close the new file after its creation
def newFile():
    """Create a new file"""
    isValid = checkFile() #isValid is the flag variable that represents whether the user input is valid in validation testing
    if isValid == False:
        fileErrorMessage()
    else:
        fileName = fileEntry.get() #fileName contains the name of the file that is obtained from the main file entry field
        newFile = open(fileName + ".txt", 'w') #newFile contains a newly created file
        newFile.close()

#Check for main file name validity with checkFile function
#Use decision for correct responses to validity check
#If the validity check has failed, output an error message
#Use fileErrorMessage function for error message
#Check for copy file name validity with checkCopy function
#If the validity check has failed, output an error message
#Use copyErrorMessage function for error message
#Use getInventoryDictionary function to obtain item dictionary from file
#Use sortInventoryDictionary function to sort the item dictionary by SKU
#Save the sorted inventory dictionary to main file with saveToFile function
#Save the sorted inventory dicitonary to copy file with saveToCopy function
def copyFile():
    """Copy file contents to a different file"""
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        inDirectory = checkDirectory() #inDirectory is the flag variable that represents whether a text file actually exists in the text file directory
        if inDirectory == False:
            notInDirectoryMessage()
        else:
            isValid = checkCopy()
            if isValid == False:
                copyErrorMessage()
            else:
                inventoryDictionary = getInventoryDictionary() #inventoryDictionary contains the dictionary of inventory items that are taken from an input file
                inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
                saveToFile(inventoryDictionary)
                saveToCopy(inventoryDictionary)

#Check for main file name validity with checkFile function
#Use decision for correct responses to validity check
#If the validity check has failed, output an error message
#Use fileErrorMessage function for error message
#If the validity check has passed, move on to the rest of the function
#Use getInventoryDictionary function to obtain item dictionary from file
#Use sortInventoryDictionary function to sort the item dictionary by SKU
#Save the sorted inventory dictionary to main file with saveToFile function
#Output sorted item inventory dictionary to user with outputInventory function
def openFile():
    """Output inventory from a file"""
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        inDirectory = checkDirectory()
        if inDirectory == False:
            notInDirectoryMessage()
        else:
            inventoryDictionary = getInventoryDictionary()
            inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
            saveToFile(inventoryDictionary)
            outputInventory(inventoryDictionary)

#Check for main file name validity with checkFile function
#Use decision for correct responses to validity check
#If the validity check has failed, output an error message
#Use fileErrorMessage function for error message
#Check for item input field validity with checkEntry function
#If the validity check has failed, output an error message
#Use entryErrorMessage function for error message
#If the validity check has passed, move on to the rest of the function
#Use getInventoryDictionary function to obtain item dictionary from file
#Use sortInventoryDictionary function to sort the item dictionary by SKU
#Use getInventoryItem function to add new item to inventory dictionary
#Use sortInventoryDictionary function to sort the item dictionary by SKU
#Save the sorted inventory dictionary to main file with saveToFile function
#Output sorted item inventory dictionary to user with outputInventory function
def addToFile():
    """Add an inventory item to a file"""
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        isValid = checkEntry()
        if isValid == False:
            entryErrorMessage()
        else:
            inDirectory = checkDirectory()
            if inDirectory == False:
                notInDirectoryMessage()
            else:
                inventoryDictionary = getInventoryDictionary()
                inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
                inventoryDictionary = getInventoryItem(inventoryDictionary)
                inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
                saveToFile(inventoryDictionary)
                outputInventory(inventoryDictionary)

#Check for main file name validity with checkFile function
#Use decision for correct responses to validity check
#If the validity check has failed, output an error message
#Use fileErrorMessage function for error message
#Check for entry field SKU validity with checkSKU function
#If the validity check has failed, output an error message
#Use skuErrorMessage function for error message
#If the validity check has passed, move on to the rest of the function
#Use getInventoryItem function to add new item to inventory dictionary
#Use sortInventoryDictionary function to sort the item dictionary by SKU
#Check if user SKU is in inventory dictionary with checkIfFromFile function
#Use notInFileMessage function to output message if user SKU is not in file
#If user SKU is in the file, set inventorySKU to user SKU from SKU entry field
#Remove SKU entry from inventory dictionary
#Save the altered inventory dictionary to main file with saveToFile function
#Output altered item inventory dictionary to user with outputInventory function
def deleteFromFile():
    """Remove an inventory item from a file"""
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        inDirectory = checkDirectory()
        if inDirectory == False:
            notInDirectoryMessage()
        else:
            isValid == checkSKU()
            if isValid == False:
                skuErrorMessage()
            else:
                inventoryDictionary = getInventoryDictionary()
                inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
                inFile = checkIfFromFile(inventoryDictionary) #inFile is the flag variable for whether an inventory item with the user input SKU actually exists in the input file
                if inFile == False:
                    notInFileMessage()
                else:
                    inventorySKU = skuEntry.get() #inventorySKU contains the SKU value for an inventory item in the inventory dictionary
                    inventoryDictionary.pop(inventorySKU)
                    saveToFile(inventoryDictionary)
                    outputInventory(inventoryDictionary)

def checkFile():
    """Check validity of main file name"""
    if fileEntry.get() == "":
        return False
    elif type(fileEntry.get()) != str:
        return False
    else:
        for key in ('/', '\\', '?', '%', '*', ':', '|', '"', '<', '>', '.', ',', ';', '=', ' '):
            if key in fileEntry.get():
                return False
        return True

def checkCopy():
    """Check validity of copy file name"""
    if fileCopyEntry.get() == "":
        return False
    elif type(fileCopyEntry.get()) != str:
        return False
    else:
        for key in ('/', '\\', '?', '%', '*', ':', '|', '"', '<', '>', '.', ',', ';', '=', ' '):
            if key in fileCopyEntry.get():
                return False
        return True

def checkDirectory():
    """Checks for existence of main file"""
    file = Path(fileEntry.get() + ".txt") #file contains the name of an input text file
    if file.is_file():
        return True
    else:
        return False

#Use elif decision structure to check for validity of user input from
    #input entry fields
#All forms of invalid input return False for validity variable
#Return True for validity variable if all checks are passed
def checkEntry():
    """Check validity of input field values"""
    if skuEntry.get() == "":
        return False
    elif nameEntry.get() == "":
        return False
    elif departmentEntry.get() == "":
        return False
    elif quantityEntry.get() == "":
        return False
    elif priceEntry.get() == "":
        return False
    elif type(skuEntry.get()) != str:
        return False
    elif type(nameEntry.get()) != str:
        return False
    elif type(departmentEntry.get()) != str:
        return False
    elif quantityEntry.get().isdigit() == False:
        return False
    elif priceEntry.get().isdigit() == False:
        return False
    elif " " in skuEntry.get():
        return False
    elif " " in nameEntry.get():
        return False
    elif " " in departmentEntry.get():
        return False
    elif " " in quantityEntry.get():
        return False
    elif " " in priceEntry.get():
        return False
    elif len(skuEntry.get()) != 4:
        return False
    elif len(nameEntry.get()) > 13:
        return False
    elif len(departmentEntry.get()) > 13:
        return False
    elif len(quantityEntry.get()) > 15:
        return False
    elif len(priceEntry.get()) > 15:
        return False
    else:
        return True

#Us elif decision structure to check for validity of user input from
    #SKU entry field
#All forms of invalid input return False for validity variable
#Return True for validity variable if all checks are passed
def checkSKU():
    """Check validity of input field SKU"""
    if skuEntry.get() == "":
        return False
    elif type(skuEntry.get()) != str:
        return False
    elif " " in skuEntry.get():
        return False
    elif len(skuEntry.get()) != 4:
        return False
    else:
        return True

#Obtain list of inventory SKUs from inventory dictionary
#Use in to determine if value from SKU entry field is within the list of keys
#Return True for in file variable if SKU is in inventory dictionary
#Return False for in file variable if SKU is not in inventory dictionary
def checkIfFromFile(inventoryDictionary):
    """Check if SKU is in main file"""
    inventorySKUs = list(inventoryDictionary.keys()) #inventorySKUs contains a list of inventory dictionary keys, which are inventory item SKU values
    if skuEntry.get() in inventorySKUs:
        return True
    else:
        return False

#Output message for invalid main file name by inserting text into output textbox
def fileErrorMessage():
    """Output error message for invalid main file name"""
    outputTextBox.insert(tk.END, "Invalid main file name\n" + \
                                 "Main file name field must be filled\n" + \
                                 "Main file name must not contain spaces\n" + \
                                 "Main file name must not contain the following characters:\n" + \
                                 "/ \\ ? % * : | \" < > . , ; =\n")

#Output message for invalid copy file name by inserting text into output textbox
def copyErrorMessage():
    """Output error message for invalid copy file name"""
    outputTextBox.insert(tk.END, "Invalid copy file name\n" + \
                         "\n")

def notInDirectoryMessage():
    outputTextBox.insert(tk.END, "File not in directory for main file name" + "\n")

#Output message for invalid entry field values by inserting text into output textbox
def entryErrorMessage():
    """Output error message for invalid input field values"""
    outputTextBox.insert(tk.END, "Invalid input\n" + \
                                 "All inventory input fields must be filled\n" + \
                                 "Inventory input must contain zero spaces\n" + \
                                 "SKU must contain four characters\n" + \
                                 "Name must be ten characters or fewer\n" + \
                                 "Department must be ten characters or fewer\n" + \
                                 "Quantity must be digits only\n" + \
                                 "Quantity must be ten digits or fewer\n" + \
                                 "Price must be digits only\n" + \
                                 "Price must be ten digits or fewer\n")

#Output message for invalid SKU entry field value by inserting text into output textbox
def skuErrorMessage():
    """Output error message for invalid input field SKU"""
    outputTextBox.insert(tk.END, "Invalid input\n"\
                                 "SKU field must be filled\n" + \
                                 "SKU must contain four characters\n")

#Output message for SKU entry field value not being in main file by inserting text into output textbox
def notInFileMessage():
    """Output message for SKU not being in main file"""
    outputTextBox.insert(tk.END, "SKU not found in inventory\n")

#Initialize the iventory dictionary
#Set file name for main file to main file entry field value
#Set the input file variable to the contents of the main file
#Remove new line from each line in input file
#Create a list of values for each line with split function
#Insert the values that represent the major characteristics of the inventory item
    #into a new list
#Insert the new list into the inventory dictionary
#Use list value from the line that represents the SKU as the key value
#Return the completed inventory dictionary
def getInventoryDictionary():
    """Obtain inventory dictionary from main file"""
    inventoryDictionary = {}
    fileName = fileEntry.get()
    inputFile = open(fileName + ".txt", 'r') #inputFile contains the name of the file from which the inventory dictionary is obtained
    for line in inputFile: #line contains each individual line of text from a text file
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]] #itemDescriptors contains the list of values that are associated with an inventory dictionary key
        inventoryDictionary[line[0]] = itemDescriptors
    return inventoryDictionary

#Inialize sorted inventory dictionary
#Obtain list of keys from inventory dictionary
#Sort the list of keys
#Add items to sorted inventory dictionary according to the order in the
    #sorted list of inventory dictionary keys
#Return the completed sorted inventory dictionary
def sortInventoryDictionary(inventoryDictionary):
    """Sort inventory dictionary by SKU"""
    sortedInventoryDictionary = {} #sortedInventoryDictionary contains the inventory dictionary that has been sorted by keys
    sortedInventorySKUs = list(inventoryDictionary.keys())
    sortedInventorySKUs.sort()
    for key in sortedInventorySKUs:
        sortedInventoryDictionary[key] = inventoryDictionary[key]
    return sortedInventoryDictionary

#Set inventory item variables to appropriate entry field values
#Convert quantity and price to float
#Pass inventory item variables to addToInventoryDictionary function
    #Function adds inventory item to inventory dictionary
#Return the altered inventory dictionary
def getInventoryItem(inventoryDictionary):
    """Obtain inventory item values from input fields"""
    inventorySKU = skuEntry.get() #inventorySKU contains the inventory item's SKU value, which is used as the key for the inventory dictionary
    inventoryName = nameEntry.get() #inventoryName contains the inventory item's name value, which is placed into a list of values for the inventory item in the inventory dictionary
    inventoryDepartment = departmentEntry.get() #inventoryDepartment contains the inventory item's department value, which is placed into a list of values for the inventory item in the inventory dictionary
    inventoryQuantity = quantityEntry.get() #inventoryQuantity contains the inventory item's quantity value, which is placed into a list of values for the inventory item in the inventory dictionary
    inventoryQuantity = float(inventoryQuantity)
    inventoryPrice = priceEntry.get() #inventoryPrice contains the inventory item's price value, which is placed into a list of values for the inventory item in the inventory dictionary
    inventoryPrice = float(inventoryPrice)
    inventoryDictionary = addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice)
    return inventoryDictionary

#Initialize list for inventory item descriptors
#Calculate inventory value by multiplying inventory quantity by inventory price
#Append inventory item descriptor list with all inventory values except for SKU
#Add list to inventory dictionary with inventory SKU as key
#Return the altered inventory dictionary
def addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice):
    """Add an inventory item to the inventory dictionary"""
    inventoryDescriptors = [] #inventoryDescriptors contains the inventory item's descriptive values, except for the SKU; the list is added to the inventory dictionary with the SKU acting as the key
    inventoryValue = inventoryQuantity * inventoryPrice #inventoryValue contains the inventory item's total monetary value, which is placed into a list of values for the inventory item in the inventory dictionary
    inventoryDescriptors.append(inventoryName)
    inventoryDescriptors.append(inventoryDepartment)
    inventoryDescriptors.append(inventoryQuantity)
    inventoryDescriptors.append(inventoryPrice)
    inventoryDescriptors.append(inventoryValue)
    inventoryDictionary[inventorySKU] = inventoryDescriptors
    return inventoryDictionary

#Set file name for main file to main file entry field value
#Set the output file variable to the contents of the main file
#Obtain list of inventory keys
#Sort the list of inventory dictionary keys
#For each key in the inventory dictionary key list, initialize a list for inventory item values
#Add the key and the value for an inventory item to the list
#Use the list of inventory item values to write the inventory item to the output file
#Format each line with a space between each inventory item value
#Add a new line at the end of each inventory item
#Close the output file
def saveToFile(inventoryDictionary):
    """Save the latest inventory dictionary to main file"""
    fileName = fileEntry.get()
    outputFile = open(fileName + ".txt", 'w') #outputFile contains the file into which the inventory dictionary is saved
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = [] #inventoryItem contains all of the values for an inventory item, and the list is used to properly format each inventory item in the output file
        inventoryItem = [key] + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                         str(inventoryItem[1]) + " " + \
                         str(inventoryItem[2]) + " " + \
                         str(inventoryItem[3]) + " " + \
                         str(inventoryItem[4]) + " " + \
                         str(inventoryItem[5]) + "\n")
    outputFile.close()

#Set file name for copy file to copy file entry field value
#Set the output file variable to the contents of the copy file
#Obtain list of inventory keys
#Sort the list of inventory dictionary keys
#For each key in the inventory dictionary key list, initialize a list for inventory item values
#Add the key and the value for an inventory item to the list
#Use the list of inventory item values to write the inventory item to the output file
#Convert each inventory item value to string
#Format each line with a space between each inventory item value
#Add a new line at the end of each inventory item
#Close the output file
def saveToCopy(inventoryDictionary):
    """Save the latest inventory dictionary to copy file"""
    fileName = fileCopyEntry.get()
    outputFile = open(fileName + ".txt", 'w')
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                         str(inventoryItem[1]) + " " + \
                         str(inventoryItem[2]) + " " + \
                         str(inventoryItem[3]) + " " + \
                         str(inventoryItem[4]) + " " + \
                         str(inventoryItem[5]) + "\n")
    outputFile.close()

#Obtain list of inventory dictionary keys
#Output table header to output textbox
#For each key value in the list of inventory dictionary keys, initialize a list for inventory item values
#Add the key and the value for an inventory item to the list
#Convert each inventory value to the correct data type
#Use the list of inventory item values to produce a formatted line for output
#Output each line to the output textbox
#Add a new line to each line of output
#Use calculateTotal function to calculate the total value of the inventory
#Output the total value of the inventory as a formatted line
def outputInventory(inventoryDictionary):
    """Output the latest inventory dictionary to the user"""
    inventorySKUs = list(inventoryDictionary.keys())
    outputTextBox.insert(tk.END, "%-6s%-15s%-15s%-17s%-17s%-25s" % ("SKU", "Name", "Department", "Quantity", "Price", "Value") +"\n")
    for key in inventorySKUs:
        inventoryItem = [] #inventoryItem contains all of the values for an inventory item, and the list is used to properly format the output to the user
        inventoryItem = [key] + inventoryDictionary[key]
        inventoryItem[0] = str(inventoryItem[0])
        inventoryItem[1] = str(inventoryItem[1])
        inventoryItem[2] = str(inventoryItem[2])
        inventoryItem[3] = float(inventoryItem[3])
        inventoryItem[4] = float(inventoryItem[4])
        inventoryItem[5] = float(inventoryItem[5])
        outputTextBox.insert(tk.END, "%-6s%-15s%-15s%-17d%-17d%-25d" % (inventoryItem[0], inventoryItem[1], \
                                                                                inventoryItem[2], inventoryItem[3], \
                                                                                inventoryItem[4], inventoryItem[5]) + "\n")
    totalInventoryValue = calculateTotal(inventoryDictionary)
    outputTextBox.insert(tk.END, "%-70s%-25d" % ("Total Inventory Value", totalInventoryValue) + "\n")

#Initialize total inventory value as zero
#Obtain list of inventory dictionary keys
#For each key in the list of inventory dictioary keys, add the inventory value to the total inventory value
#Return the total inventory value
def calculateTotal(inventoryDictionary):
    """Calculate the total value of inventory with cost of inventory items"""
    totalInventoryValue = 0 #totalInventoryValue contains the total monetary value of all inventory items in the inventory dictionary
    inventorySKUs = list(inventoryDictionary.keys())
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        totalInventoryValue += float(inventoryItem[5])
    return totalInventoryValue

#Use destroy function to close both input window and output window
def closeProgram():
    """Close both windows of the program"""
    inputWindow.destroy()
    outputWindow.destroy()

#Instantiate label for main file entry field
#Instantiate main file entry field
#Use .grid to properly position the widgets
fileLabel = tk.Label(inputWindow, text="Main File Name:") #fileLabel is used to indicate the purpose of the main file entry field
fileLabel.grid(row=0, column=1)
fileEntry = tk.Entry(inputWindow, text="") #fileEntry is used for user input for the main file name
fileEntry.grid(row=0, column=2)

#Instantiate label for copy file entry field
#Instantiate copy file entry field
#Use .grid to properly position the widgets
fileCopyLabel = tk.Label(inputWindow, text="Copy File Name:") #fileCopyLabel is used to indicate the purpose of the copy file entry field
fileCopyLabel.grid(row=1, column=1)
fileCopyEntry = tk.Entry(inputWindow, text="") #fileCopyEntry is used for user input for the copy file name
fileCopyEntry.grid(row=1, column=2)

#Instantiate frame for blank line
#Instantiate label for blank line
#Use .pack to properly position the blank line
paddingFrame = tk.Frame(inputWindow) #paddingFrame is used to create a blank line between the file entry fields and the inventory item entry fields
paddingFrame.grid(row=2, column=0, columnspan=4)
paddingLabel = tk.Label(master=paddingFrame, text="", width=40) #paddingLabel is used to make paddingFrame visible as an empty space
paddingLabel.pack()

#Instantiate label for SKU entry field
#Instantiate SKU entry field
#Use .grid to properly position the widgets
skuLabel = tk.Label(inputWindow, text="SKU:") #skuLabel is used to indicate the purpose of the SKU entry field
skuLabel.grid(row=3, column=1)
skuEntry = tk.Entry(inputWindow, text="") #skuEntry is used for user input for the inventory item's SKU value
skuEntry.grid(row=3, column=2)

#Instantiate label for name entry field
#Instantiate name entry field
#Use .grid to properly position the widgets
nameLabel = tk.Label(inputWindow, text="Item Name:") #nameLabel is used to indicate the purpose of the name entry field
nameLabel.grid(row=4, column=1)
nameEntry = tk.Entry(inputWindow, text="") #nameEntry is used for user input for the inventory item's name value
nameEntry.grid(row=4, column=2)

#Instantiate label for document entry field
#Instantiate document entry field
#Use .grid to properly position the widgets
departmentLabel = tk.Label(inputWindow, text="Department:") #departmentLabel is used to indicate the purpose of the department entry field
departmentLabel.grid(row=5, column=1)
departmentEntry = tk.Entry(inputWindow, text="") #departmentEntry is used for user input for the inventory item's department value
departmentEntry.grid(row=5, column=2)

#Instantiate label for quantity entry field
#Instantiate quantity entry field
#Use .grid to properly position the widgets
quantityLabel = tk.Label(inputWindow, text="Quantity:") #quantityLabel is used to indicate the purpose of the quantity entry field
quantityLabel.grid(row=6, column=1)
quantityEntry = tk.Entry(inputWindow, text="") #quantityEntry is used for user input for the inventory item's quantity value
quantityEntry.grid(row=6, column=2)

#Instantiate label for price entry field
#Instantiate price entry field
#Use .grid to properly position the widgets
priceLabel = tk.Label(inputWindow, text="Price:") #priceLabel is used to indicate the purpose of the price entry field
priceLabel.grid(row=7, column=1)
priceEntry = tk.Entry(inputWindow, text="") #priceEntry is used for user input for the inventory item's price value
priceEntry.grid(row=7, column=2)

#Instantiate frame for blank line
#Instantiate label for blank line
#Use .pack to properly position the blank line
paddingFrameTwo = tk.Frame(inputWindow) #paddingFrameTwo is used to create a blank line between the inventory item entry fields and the buttons
paddingFrameTwo.grid(row=8, column=0, columnspan=4)
paddingLabelTwo = tk.Label(master=paddingFrameTwo, text="") #paddingLabelTwo is used to make paddingFrameTwo visible as an empty space
paddingLabelTwo.pack()

#Obtain a render for the "New File" icon
#Instantiate "New File" button
#Add "New File" icon to button
#Connect button to newFile command
#Use .grid to properly position the button
newFileImage = Image.open("New_File.png") #newFileImage contains the "New_File.png" file, which acts as the "New File" icon
newFileRender = ImageTk.PhotoImage(newFileImage, master=inputWindow) #newFileRender contains the tkinter render of the "New File" icon
newFileButton = tk.Button(inputWindow, image=newFileRender, text="New File", compound="top", command=newFile) #newFileButton is used for the creation of new files
newFileButton.grid(row=9, column=1)

#Obtain a render for the "Copy File" icon
#Instantiate "Copy File" button
#Add "Copy File" icon to button
#Connect button to copyFile command
#Use .grid to properly position the button
copyFileImage = Image.open("Copy_File.png") #copyFileImage contains the "Copy_File.png" file, which acts as the "Copy File" icon
copyFileRender = ImageTk.PhotoImage(copyFileImage, master=inputWindow) #copyFileRender contains the tkinter render of the "Copy File" icon
copyFileButton = tk.Button(inputWindow, image=copyFileRender, text="Copy File", compound="top", command=copyFile) #copyFileButton is used for copying the contents of one file to another file
copyFileButton.grid(row=9, column=2)

#Obtain a render for the "Open File" icon
#Instantiate "Open File" button
#Add "Open File" icon to button
#Connect button to openFile command
#Use .grid to properly position the button
openFileImage = Image.open("Open_File.png") #openFileImage contains the "Open_File.png" file, which acts as the "Open File" icon
openFileRender = ImageTk.PhotoImage(openFileImage, master=inputWindow) #openFileRender contains the tkinter render of the "Open File" icon
openFileButton = tk.Button(inputWindow, image=openFileRender, text="Open File", compound="top", command=openFile) #openFileButton is used for displaying the inventory of a file to the user
openFileButton.grid(row=10, column=1)

#Obtain a render for the "Add To File" icon
#Instantiate "Add To File" button
#Add "Add To File" icon to button
#Connect button to addToFile command
#Use .grid to properly position the button
addToFileImage = Image.open("Add_To_File.png") #addToFileImage contains the "Add_To_File.png" file, which acts as the "Add To File" icon
addToFileRender = ImageTk.PhotoImage(addToFileImage, master=inputWindow) #addToFileRender contains the tkinter render of the "Add To File" icon
addToFileButton = tk.Button(inputWindow, image=addToFileRender, text="Add To File", compound="top", command=addToFile) #addToFileButton is used for adding an inventory item to a file
addToFileButton.grid(row=10, column=2)

#Obtain a render for the "Delete From Inventory" icon
#Instantiate "Delete From Inventory" button
#Add "Delete From Inventory" icon to button
#Connect button to deleteFromFile command
#Use .grid to properly position the button
deleteFromInventoryImage = Image.open("Delete_From_Inventory.png") #deleteFromInventoryImage contains the "Delete_From_Inventory.png" file, which acts as the "Delete From Inventory" icon
deleteFromInventoryRender = ImageTk.PhotoImage(deleteFromInventoryImage, master=inputWindow) #deleteFromInventoryRender contains the tkinter render of the "Delete From Inventory" icon
deleteFromInventoryButton = tk.Button(inputWindow, image=deleteFromInventoryRender, text="Delete From Inventory", compound="top", command=deleteFromFile) #deleteFromInventoryButton button is used for removing an inventory item from a file
deleteFromInventoryButton.grid(row=11, column=1)

#Obtain a render for the "Close Program" icon
#Instantiate "Close Program" button
#Add "Close Program" icon to button
#Connect button to closeProgram command
#Use .grid to properly position the button
closeProgramImage = Image.open("Close_Program.png") #closeProgramImage contains the "Close Program.png" file, which acts as the "Close Program" icon
closeProgramRender = ImageTk.PhotoImage(closeProgramImage, master=inputWindow) #closeProgramRender contains the tkinter render of the "Close Program" icon
closeButton = tk.Button(inputWindow, image=closeProgramRender, text="Close Program", compound="top", command=closeProgram) #closeButton is used to close the program
closeButton.grid(row=11, column=2)

#Set inputWindow to mainloop
inputWindow.mainloop()
