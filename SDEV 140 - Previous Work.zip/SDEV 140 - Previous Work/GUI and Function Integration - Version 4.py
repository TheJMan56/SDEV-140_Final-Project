"""
Author: Justin W Daily
Date written: 03/09/23
Assignment: DailyJustinWFinalProject
Version of Python: 3.11.1

Short Desc: 
"""

import tkinter as tk

outputWindow = tk.Tk()

outputInventory = tk.Text(outputWindow, width=100)
outputInventory.pack()

inputWindow = tk.Tk()

def addToFileCheck():
    """"""
    if skuEntry.get() == "":
        isValid = False
    elif nameEntry.get() == "":
        isValid = False
    elif departmentEntry.get() == "":
        isValid = False
    elif quantityEntry.get() == "":
        isValid = False
    elif priceEntry.get() == "":
        isValid = False
    elif type(skuEntry.get()) != str:
        isValid = False
    elif type(nameEntry.get()) != str:
        isValid = False
    elif type(departmentEntry.get()) != str:
        isValid = False
    elif quantityEntry.get().isdigit() == False:
        isValid = False
    elif priceEntry.get().isdigit() == False:
        isValid = False
    elif " " in skuEntry.get():
        isValid = False
    elif " " in nameEntry.get():
        isValid = False
    elif " " in departmentEntry.get():
        isValid = False
    elif " " in quantityEntry.get():
        isValid = False
    elif " " in priceEntry.get():
        isValid = False
    elif len(skuEntry.get()) != 4:
        isValid = False
    elif len(nameEntry.get()) > 13:
        isValid = False
    elif len(departmentEntry.get()) > 13:
        isValid = False
    elif len(quantityEntry.get()) > 15:
        isValid = False
    elif len(priceEntry.get()) > 15:
        isValid = False
    else:
        isValid = True

    if isValid == False:
        outputInventory.insert(tk.END, "Invalid input\n"\
                               "All inventory input fields must be filled\n" + \
                               "Inventory input must contain zero spaces\n" + \
                               "SKU must contain four characters\n" + \
                               "Name must be ten characters or fewer\n" + \
                               "Department must be ten characters or fewer\n" + \
                               "Quantity must be digits only\n" + \
                               "Quantity must be ten digits or fewer\n" + \
                               "Price must be digits only\n" + \
                               "Price must be ten digits or fewer\n" + "\n")
    else:
        addToFile()

def checkSKU():
    if skuEntry.get() == "":
        isValid = False
    elif type(skuEntry.get()) != str:
        isValid = False
    elif " " in skuEntry.get():
        isValid = False
    elif len(skuEntry.get()) != 4:
        isValid = False
    else:
        isValid = True

    if isValid == False:
        outputInventory.insert(tk.END, "Invalid input\n"\
                               "SKU field must be filled\n" + \
                               "SKU must contain four characters\n" + "\n")
    else:
        checkIfFromFile()

def checkIfFromFile():
    inventoryDictionary = {}
    fileName = fileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    inventorySKUs = list(inventoryDictionary.keys())
    if skuEntry.get() in inventorySKUs:
        deleteFromFile()
    else:
        outputInventory.insert(tk.END, "SKU not found in inventory" + "\n")

def newFile():
    fileName = fileEntry.get()
    newFile = open(fileName, 'w')
    newFile.close()

def openFile():
    inventoryDictionary = {}
    fileName = fileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    outputInventoryDictionary(inventoryDictionary)
    inputFile.close()

def copyFile():
    inventoryDictionary = {}
    fileName = fileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    inputFile.close()
    fileName = fileCopyEntry.get()
    outputFile = open(fileName, 'w')
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                         str(inventoryItem[1]) + " " + \
                         str(inventoryItem[2]) + " " + \
                         str(inventoryItem[3]) + " " + \
                         str(inventoryItem[4]) + " " + \
                         str(inventoryItem[5]) + "\n")
    outputFile.close()

def getFileInventory():
    inventoryDictionary = {}
    fileName = fileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    inputFile.close()
    return inventoryDictionary

def sortInventoryDictionary(inventoryDictionary):
    """Produce an inventory dictionary sorted by SKU"""
    sortedInventoryDictionary = {}
    sortedInventorySKUs = list(inventoryDictionary.keys())
    sortedInventorySKUs.sort()
    for key in sortedInventorySKUs:
        sortedInventoryDictionary[key] = inventoryDictionary[key]
    return sortedInventoryDictionary

def outputInventoryDictionary(inventoryDictionary):
    inventorySKUs = list(inventoryDictionary.keys())
    outputInventory.insert(tk.END, "%-6s%-15s%-15s%-17s%-17s%-25s" % ("SKU", "Name", "Department", "Quantity", "Price", "Value") +"\n")
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        inventoryItem[0] = str(inventoryItem[0])
        inventoryItem[1] = str(inventoryItem[1])
        inventoryItem[2] = str(inventoryItem[2])
        inventoryItem[3] = float(inventoryItem[3])
        inventoryItem[4] = float(inventoryItem[4])
        inventoryItem[5] = float(inventoryItem[5])
        outputInventory.insert(tk.END, "%-6s%-15s%-15s%-17d%-17d%-25d" % (inventoryItem[0], inventoryItem[1], \
                                                                                inventoryItem[2], inventoryItem[3], \
                                                                                inventoryItem[4], inventoryItem[5]) + "\n")
    totalInventoryValue = calculateTotal(inventoryDictionary)
    outputInventory.insert(tk.END, "%-70s%-25d" % ("Total Inventory Value", totalInventoryValue) + "\n")

def calculateTotal(inventoryDictionary):
    totalInventoryValue = 0
    inventorySKUs = list(inventoryDictionary.keys())
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        totalInventoryValue += float(inventoryItem[5])
    return totalInventoryValue

def addToFile():
    inventoryDictionary = getFileInventory()
    inventorySKU = skuEntry.get()
    inventoryName = nameEntry.get()
    inventoryDepartment = departmentEntry.get()
    inventoryQuantity = quantityEntry.get()
    inventoryQuantity = float(inventoryQuantity)
    inventoryPrice = priceEntry.get()
    inventoryPrice = float(inventoryPrice)
    inventoryDictionary = addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice)
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    saveToFile(inventoryDictionary)
    openFile()

def addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice):
    """Add inventory items to the inventory dictionary"""
    inventoryDescriptors = []
    inventoryValue = inventoryQuantity * inventoryPrice
    inventoryDescriptors.append(inventoryName)
    inventoryDescriptors.append(inventoryDepartment)
    inventoryDescriptors.append(inventoryQuantity)
    inventoryDescriptors.append(inventoryPrice)
    inventoryDescriptors.append(inventoryValue)
    inventoryDictionary[inventorySKU] = inventoryDescriptors
    return inventoryDictionary

def saveToFile(inventoryDictionary):
    fileName = fileEntry.get()
    outputFile = open(fileName, 'w')
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                         str(inventoryItem[1]) + " " + \
                         str(inventoryItem[2]) + " " + \
                         str(inventoryItem[3]) + " " + \
                         str(inventoryItem[4]) + " " + \
                         str(inventoryItem[5]) + "\n")
    outputFile.close()

def deleteFromFile():
    inventoryDictionary = getFileInventory()
    inventorySKU = skuEntry.get()
    inventoryDictionary.pop(inventorySKU)
    saveToFile(inventoryDictionary)
    openFile()

def closeProgram():
    """"""

fileLabel = tk.Label(inputWindow, text="File name:")
fileLabel.pack()

fileEntry = tk.Entry(inputWindow, text="")
fileEntry.pack()

fileCopyEntry = tk.Entry(inputWindow, text="")
fileCopyEntry.pack()

paddingFrameOne = tk.Frame(inputWindow)
paddingFrameOne.pack()

paddingLabelOne = tk.Label(master=paddingFrameOne, text="", width=40)
paddingLabelOne.pack()

skuLabel = tk.Label(inputWindow, text="SKU:")
skuLabel.pack()

skuEntry = tk.Entry(inputWindow, text="")
skuEntry.pack()

nameLabel = tk.Label(inputWindow, text="Item Name:")
nameLabel.pack()

nameEntry = tk.Entry(inputWindow, text="")
nameEntry.pack()

departmentLabel = tk.Label(inputWindow, text="Department:")
departmentLabel.pack()

departmentEntry = tk.Entry(inputWindow, text="")
departmentEntry.pack()

quantityLabel = tk.Label(inputWindow, text="Quantity:")
quantityLabel.pack()

quantityEntry = tk.Entry(inputWindow, text="")
quantityEntry.pack()

priceLabel = tk.Label(inputWindow, text="Price:")
priceLabel.pack()

priceEntry = tk.Entry(inputWindow, text="")
priceEntry.pack()

paddingFrameTwo = tk.Frame(inputWindow)
paddingFrameTwo.pack()

paddingLabelTwo = tk.Label(master=paddingFrameTwo, text="")
paddingLabelTwo.pack()

newFileButton = tk.Button(inputWindow, text="New File", command=newFile)
newFileButton.pack()

copyFileButton = tk.Button(inputWindow, text="Copy File", command=copyFile)
copyFileButton.pack()

openFileButton = tk.Button(inputWindow, text="Open File", command=openFile)
openFileButton.pack()

addToFileButton = tk.Button(inputWindow, text="Add To File", command=addToFileCheck)
addToFileButton.pack()

deleteFromInventoryButton = tk.Button(inputWindow, text="Delete From Inventory", command=checkSKU)
deleteFromInventoryButton.pack()

closeButton = tk.Button(inputWindow, text="Close Program", command=closeProgram)
closeButton.pack()

outputWindow.mainloop()
