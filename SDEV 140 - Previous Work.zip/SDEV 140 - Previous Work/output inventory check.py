def openFile():
    inventoryDictionary = {}
    fileName = "inventory.txt"
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
    outputInventoryDictionary(inventoryDictionary)
    inputFile.close()

def sortInventoryDictionary(inventoryDictionary):
    """Produce an inventory dictionary sorted by SKU"""
    sortedInventoryDictionary = {}
    sortedInventorySKUs = list(inventoryDictionary.keys())
    sortedInventorySKUs.sort()
    for key in sortedInventorySKUs:
        sortedInventoryDictionary[key] = inventoryDictionary[key]
    return sortedInventoryDictionary

def calculateTotal(inventoryDictionary):
    totalInventoryValue = 0
    inventorySKUs = list(inventoryDictionary.keys())
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        totalInventoryValue += float(inventoryItem[5])
    return totalInventoryValue

def outputInventoryDictionary(inventoryDictionary):
    inventorySKUs = list(inventoryDictionary.keys())
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        print(key)
        print(inventoryItem)
        inventoryItem[0] = str(inventoryItem[0])
        inventoryItem[1] = str(inventoryItem[1])
        inventoryItem[2] = str(inventoryItem[2])
        inventoryItem[3] = float(inventoryItem[3])
        inventoryItem[4] = float(inventoryItem[4])
        inventoryItem[5] = float(inventoryItem[5])
        print("%-5s%-15s%-15s%-10.2f%-10.2f%-20.2f" % (inventoryItem[0], inventoryItem[1], \
                                                       inventoryItem[2], inventoryItem[3], \
                                                       inventoryItem[4], inventoryItem[5]) + "\n")
    totalInventoryValue = calculateTotal(inventoryDictionary)
    print("%-55s%-20.2f" % ("Total Inventory Value", totalInventoryValue) + "\n")

openFile()
