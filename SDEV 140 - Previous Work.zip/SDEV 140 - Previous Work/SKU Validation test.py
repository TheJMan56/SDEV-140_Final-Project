def checkSKU(userSKU):
    """Check validity of input field SKU"""
    if userSKU == "":
        print("Invalid")
    elif type(userSKU) != str:
        print("Invalid")
    elif " " in userSKU:
        print ("Invalid")
    elif len(userSKU) != 4:
        print("Invalid")
    else:
        print("Valid")

while True:
    userSKU = input("Enter an SKU: ")
    if userSKU == "QUIT":
        break
    checkSKU(userSKU)
