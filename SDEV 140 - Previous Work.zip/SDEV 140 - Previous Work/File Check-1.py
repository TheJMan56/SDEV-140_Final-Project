from pathlib import Path

my_file = Path("inventory.txt")
if my_file.is_file():
    print("Is file")
else:
    print("Is not file")

if '/' or '\\' or '?' or '%' or '*' or ':' or '|' or '"' or '<' or '>' or '.' or ',' or ';' or '=' or ' ' in "inventory":
    print("Is not valid")
else:
    print("Is valid")

for key in ('/', '\\', '?', '%', '*', ':', '|', '"', '<', '>', '.', ',', ';', '=', ' '):
    if key in "inventory\\":
        print("Is not valid")
    else:
        print("Is valid")
