import tkinter as tk

inputWindow = tk.Tk()

outputWindow = tk.Tk()

outputInventory = tk.Text(outputWindow)
outputInventory.pack()

fileLabel = tk.Label(inputWindow, text="File name:")
fileLabel.pack()

fileEntry = tk.Entry(inputWindow, text="")
fileEntry.pack()

paddingFrameOne = tk.Frame(inputWindow)
paddingFrameOne.pack()

paddingLabelOne = tk.Label(master=paddingFrameOne, text="", width=40)
paddingLabelOne.pack()

skuLabel = tk.Label(inputWindow, text="SKU:")
skuLabel.pack()

skuEntry = tk.Entry(inputWindow, text="")
skuEntry.pack()

nameLabel = tk.Label(inputWindow, text="Item Name:")
nameLabel.pack()

nameEntry = tk.Entry(inputWindow, text="")
nameEntry.pack()

departmentLabel = tk.Label(inputWindow, text="Department:")
departmentLabel.pack()

departmentEntry = tk.Entry(inputWindow, text="")
departmentEntry.pack()

quantityLabel = tk.Label(inputWindow, text="Quantity:")
quantityLabel.pack()

quantityEntry = tk.Entry(inputWindow, text="")
quantityEntry.pack()

priceLabel = tk.Label(inputWindow, text="Price:")
priceLabel.pack()

priceEntry = tk.Entry(inputWindow, text="")
priceEntry.pack()

paddingFrameTwo = tk.Frame(inputWindow)
paddingFrameTwo.pack()

paddingLabelTwo = tk.Label(master=paddingFrameTwo, text="")
paddingLabelTwo.pack()

openFileButton = tk.Button(inputWindow, text="Open File")
openFileButton.pack()

addToFileButton = tk.Button(inputWindow, text="Add To File")
addToFileButton.pack()

printInventoryButton = tk.Button(inputWindow, text="Print Inventory")
printInventoryButton.pack()

outputWindow.mainloop()
