inventoryDictionary = {}
departmentList = []
totalInventoryValue = 0

def addInventory():
    """Add items to inventory"""
    while True:
        inventorySKU = input("Please enter the SKU of the inventory item: ")
        if inventorySKU == "":
            break
        inventoryName = input("Please enter the name of the inventory item: ")
        inventoryDepartment = input("Please enter the department of the inventory: ")
        departmentList = addToDepartmentList(inventoryDepartment)
        inventoryQuantity = float(input("Please enter the quantity of the inventory: "))
        inventoryPrice = float(input("Please enter the cost per quantity of the inventory: "))
        inventoryDictionary = addToInventoryDictionary(inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice)

def addToInventoryDictionary(inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice):
    """Add inventory items to the inventory dictionary"""
    inventoryDescriptors = []
    inventoryValue = inventoryQuantity * inventoryPrice
    inventoryDescriptors.append(inventoryName)
    inventoryDescriptors.append(inventoryDepartment)
    inventoryDescriptors.append(inventoryQuantity)
    inventoryDescriptors.append(inventoryPrice)
    inventoryDescriptors.append(inventoryValue)
    inventoryDictionary[inventorySKU] = inventoryDescriptors
    return inventoryDictionary

def sortInventoryDictionary(inventoryDictionary):
    """Produce an inventory dictionary sorted by SKU"""
    sortedInventoryDictionary = {}
    sortedInventorySKUs = list(inventoryDictionary.keys())
    sortedInventorySKUs.sort()
    for key in sortedInventorySKUs:
        sortedInventoryDictionary[key] = inventoryDictionary[key]
    return sortedInventoryDictionary

def addToDepartmentList(inventoryDepartment):
    """Add a department to the department list"""
    if inventoryDepartment not in departmentList:
        departmentList.append(inventoryDepartment)
        departmentList.sort()
        return departmentList

def saveToFile(inventoryDictionary):
    """Save inventory list to file"""
    fileName = input("Enter the name of the file: ")
    outputFile = open(fileName, 'w')
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = list(key) + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                       str(inventoryItem[1]) + " " + \
                       str(inventoryItem[2]) + " " + \
                       str(inventoryItem[3]) + " " + \
                       str(inventoryItem[4]) + " " + \
                       str(inventoryItem[5]) + "\n")
    outputFile.close

addInventory()

inventoryDictionary = sortInventoryDictionary(inventoryDictionary)

saveToFile(inventoryDictionary)

fileName = input("Enter the name of the file: ")
inputFile = open(fileName, 'r')
items = inputFile.read()

print(items)
