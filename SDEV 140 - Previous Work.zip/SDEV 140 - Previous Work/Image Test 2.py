from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk

inputWindow = tk.Tk()

def newFile():
    return

newFileImage = Image.open("New_File.png")
newFileRender = ImageTk.PhotoImage(newFileImage)
newFileButton = tk.Button(inputWindow, image=newFileRender, text="New File", compound="top", command=newFile) #newFileButton is used for the creation of new files
newFileButton.grid(row=9, column=1)

inputWindow.mainloop()
