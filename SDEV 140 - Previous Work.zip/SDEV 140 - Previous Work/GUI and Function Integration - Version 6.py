"""
Author: Justin W Daily
Date written: 03/09/23
Assignment: DailyJustinWFinalProject
Version of Python: 3.11.1

Short Desc: 
"""

import tkinter as tk

outputWindow = tk.Tk()

outputTextBox = tk.Text(outputWindow, width=100)
outputTextBox.pack()

inputWindow = tk.Tk()

def newFile():
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        fileName = fileEntry.get()
        newFile = open(fileName, 'w')
        newFile.close()

def copyFile():
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        isValid = checkCopy()
        if isValid == False:
            copyErrorMessage()
        else:
            inventoryDictionary = getInventoryDictionary()
            inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
            saveToFile(inventoryDictionary)
            saveToCopy(inventoryDictionary)

def openFile():
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        inventoryDictionary = getInventoryDictionary()
        inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
        saveToFile(inventoryDictionary)
        outputInventory(inventoryDictionary)

def addToFile():
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        isValid = checkEntry()
        if isValid == False:
            entryErrorMessage()
        else:
            inventoryDictionary = getInventoryDictionary()
            inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
            inventoryDictionary = getInventoryItem(inventoryDictionary)
            saveToFile(inventoryDictionary)
            outputInventory(inventoryDictionary)

def deleteFromFile():
    isValid = checkFile()
    if isValid == False:
        fileErrorMessage()
    else:
        isValid == checkSKU()
        if isValid == False:
            skuErrorMessage()
        else:
            inventoryDictionary = getInventoryDictionary()
            inventoryDictionary = sortInventoryDictionary(inventoryDictionary)
            inFile = checkIfFromFile(inventoryDictionary)
            if inFile == False:
                notInFileMessage()
            else:
                inventorySKU = skuEntry.get()
                inventoryDictionary.pop(inventorySKU)
                saveToFile(inventoryDictionary)
                outputInventory(inventoryDictionary)

def checkFile():
    return True

def checkCopy():
    return True

def checkEntry():
    if skuEntry.get() == "":
        return False
    elif nameEntry.get() == "":
        return False
    elif departmentEntry.get() == "":
        return False
    elif quantityEntry.get() == "":
        return False
    elif priceEntry.get() == "":
        return False
    elif type(skuEntry.get()) != str:
        return False
    elif type(nameEntry.get()) != str:
        return False
    elif type(departmentEntry.get()) != str:
        return False
    elif quantityEntry.get().isdigit() == False:
        return False
    elif priceEntry.get().isdigit() == False:
        return False
    elif " " in skuEntry.get():
        return False
    elif " " in nameEntry.get():
        return False
    elif " " in departmentEntry.get():
        return False
    elif " " in quantityEntry.get():
        return False
    elif " " in priceEntry.get():
        return False
    elif len(skuEntry.get()) != 4:
        return False
    elif len(nameEntry.get()) > 13:
        return False
    elif len(departmentEntry.get()) > 13:
        return False
    elif len(quantityEntry.get()) > 15:
        return False
    elif len(priceEntry.get()) > 15:
        return False
    else:
        return True

def checkSKU():
    if skuEntry.get() == "":
        return False
    elif type(skuEntry.get()) != str:
        return False
    elif " " in skuEntry.get():
        return False
    elif len(skuEntry.get()) != 4:
        return False
    else:
        return True

def checkIfFromFile(inventoryDictionary):
    inventorySKUs = list(inventoryDictionary.keys())
    if skuEntry.get() in inventorySKUs:
        return True
    else:
        return False

def fileErrorMessage():
    "Invalid file name"

def copyErrorMessage():
    "Invalid copy name"

def entryErrorMessage():
    outputTextBox.insert(tk.END, "Invalid input\n"\
                                 "All inventory input fields must be filled\n" + \
                                 "Inventory input must contain zero spaces\n" + \
                                 "SKU must contain four characters\n" + \
                                 "Name must be ten characters or fewer\n" + \
                                 "Department must be ten characters or fewer\n" + \
                                 "Quantity must be digits only\n" + \
                                 "Quantity must be ten digits or fewer\n" + \
                                 "Price must be digits only\n" + \
                                 "Price must be ten digits or fewer\n" + "\n")

def skuErrorMessage():
    outputTextBox.insert(tk.END, "Invalid input\n"\
                                 "SKU field must be filled\n" + \
                                 "SKU must contain four characters\n" + "\n")

def notInFileMessage():
    outputTextBox.insert(tk.END, "SKU not found in inventory" + "\n")

def getInventoryDictionary():
    inventoryDictionary = {}
    fileName = fileEntry.get()
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
    return inventoryDictionary

def sortInventoryDictionary(inventoryDictionary):
    sortedInventoryDictionary = {}
    sortedInventorySKUs = list(inventoryDictionary.keys())
    sortedInventorySKUs.sort()
    for key in sortedInventorySKUs:
        sortedInventoryDictionary[key] = inventoryDictionary[key]
    return sortedInventoryDictionary

def getInventoryItem(inventoryDictionary):
    inventorySKU = skuEntry.get()
    inventoryName = nameEntry.get()
    inventoryDepartment = departmentEntry.get()
    inventoryQuantity = quantityEntry.get()
    inventoryQuantity = float(inventoryQuantity)
    inventoryPrice = priceEntry.get()
    inventoryPrice = float(inventoryPrice)
    inventoryDictionary = addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice)
    return inventoryDictionary

def addToInventoryDictionary(inventoryDictionary, inventorySKU, inventoryName, inventoryDepartment, inventoryQuantity, inventoryPrice):
    inventoryDescriptors = []
    inventoryValue = inventoryQuantity * inventoryPrice
    inventoryDescriptors.append(inventoryName)
    inventoryDescriptors.append(inventoryDepartment)
    inventoryDescriptors.append(inventoryQuantity)
    inventoryDescriptors.append(inventoryPrice)
    inventoryDescriptors.append(inventoryValue)
    inventoryDictionary[inventorySKU] = inventoryDescriptors
    return inventoryDictionary

def saveToFile(inventoryDictionary):
    fileName = fileEntry.get()
    outputFile = open(fileName, 'w')
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                         str(inventoryItem[1]) + " " + \
                         str(inventoryItem[2]) + " " + \
                         str(inventoryItem[3]) + " " + \
                         str(inventoryItem[4]) + " " + \
                         str(inventoryItem[5]) + "\n")
    outputFile.close()

def saveToCopy(inventoryDictionary):
    fileName = fileCopyEntry.get()
    outputFile = open(fileName, 'w')
    inventorySKUs = list(inventoryDictionary.keys())
    inventorySKUs.sort()
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        outputFile.write(str(inventoryItem[0]) + " " + \
                         str(inventoryItem[1]) + " " + \
                         str(inventoryItem[2]) + " " + \
                         str(inventoryItem[3]) + " " + \
                         str(inventoryItem[4]) + " " + \
                         str(inventoryItem[5]) + "\n")
    outputFile.close()

def outputInventory(inventoryDictionary):
    inventorySKUs = list(inventoryDictionary.keys())
    outputTextBox.insert(tk.END, "%-6s%-15s%-15s%-17s%-17s%-25s" % ("SKU", "Name", "Department", "Quantity", "Price", "Value") +"\n")
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        inventoryItem[0] = str(inventoryItem[0])
        inventoryItem[1] = str(inventoryItem[1])
        inventoryItem[2] = str(inventoryItem[2])
        inventoryItem[3] = float(inventoryItem[3])
        inventoryItem[4] = float(inventoryItem[4])
        inventoryItem[5] = float(inventoryItem[5])
        outputTextBox.insert(tk.END, "%-6s%-15s%-15s%-17d%-17d%-25d" % (inventoryItem[0], inventoryItem[1], \
                                                                                inventoryItem[2], inventoryItem[3], \
                                                                                inventoryItem[4], inventoryItem[5]) + "\n")
    totalInventoryValue = calculateTotal(inventoryDictionary)
    outputTextBox.insert(tk.END, "%-70s%-25d" % ("Total Inventory Value", totalInventoryValue) + "\n")

def calculateTotal(inventoryDictionary):
    totalInventoryValue = 0
    inventorySKUs = list(inventoryDictionary.keys())
    for key in inventorySKUs:
        inventoryItem = []
        inventoryItem = [key] + inventoryDictionary[key]
        totalInventoryValue += float(inventoryItem[5])
    return totalInventoryValue

def closeProgram():
    inputWindow.destroy()
    outputWindow.destroy()

fileLabel = tk.Label(inputWindow, text="File name:")
fileLabel.pack()

fileEntry = tk.Entry(inputWindow, text="")
fileEntry.pack()

fileCopyEntry = tk.Entry(inputWindow, text="")
fileCopyEntry.pack()

paddingFrameOne = tk.Frame(inputWindow)
paddingFrameOne.pack()

paddingLabelOne = tk.Label(master=paddingFrameOne, text="", width=40)
paddingLabelOne.pack()

skuLabel = tk.Label(inputWindow, text="SKU:")
skuLabel.pack()

skuEntry = tk.Entry(inputWindow, text="")
skuEntry.pack()

nameLabel = tk.Label(inputWindow, text="Item Name:")
nameLabel.pack()

nameEntry = tk.Entry(inputWindow, text="")
nameEntry.pack()

departmentLabel = tk.Label(inputWindow, text="Department:")
departmentLabel.pack()

departmentEntry = tk.Entry(inputWindow, text="")
departmentEntry.pack()

quantityLabel = tk.Label(inputWindow, text="Quantity:")
quantityLabel.pack()

quantityEntry = tk.Entry(inputWindow, text="")
quantityEntry.pack()

priceLabel = tk.Label(inputWindow, text="Price:")
priceLabel.pack()

priceEntry = tk.Entry(inputWindow, text="")
priceEntry.pack()

paddingFrameTwo = tk.Frame(inputWindow)
paddingFrameTwo.pack()

paddingLabelTwo = tk.Label(master=paddingFrameTwo, text="")
paddingLabelTwo.pack()

newFileButton = tk.Button(inputWindow, text="New File", command=newFile)
newFileButton.pack()

copyFileButton = tk.Button(inputWindow, text="Copy File", command=copyFile)
copyFileButton.pack()

openFileButton = tk.Button(inputWindow, text="Open File", command=openFile)
openFileButton.pack()

addToFileButton = tk.Button(inputWindow, text="Add To File", command=addToFile)
addToFileButton.pack()

deleteFromInventoryButton = tk.Button(inputWindow, text="Delete From Inventory", command=deleteFromFile)
deleteFromInventoryButton.pack()

closeButton = tk.Button(inputWindow, text="Close Program", command=closeProgram)
closeButton.pack()

outputWindow.mainloop()
