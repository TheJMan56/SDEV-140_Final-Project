from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk

window = tk.Tk()

try:
    newFileImage = Image.open("Nesw_File.png")
    render = ImageTk.PhotoImage(newFileImage)
except:
    render = "Filler text"

#frame = tk.Frame(window)
#frame.pack()

if render == "Filler text":
    button = tk.Button(window, text="New File")
    button.pack()
else:
    button = tk.Button(window, image=render, text="New File", compound="top")
    button.pack()

window.mainloop()
