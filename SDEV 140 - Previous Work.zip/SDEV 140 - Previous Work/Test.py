from tkinter import *
root=Tk()
a=Label(root,text='Hello World!', sticky="e")
a.pack()
b=Label(root,text='Bye World')
b.pack()
