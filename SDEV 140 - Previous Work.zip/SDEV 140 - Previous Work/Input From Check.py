def printFile():
    inventoryDictionary = {}
    inventoryTotal = 0
    fileName = input("Enter the name of the file: ")
    inputFile = open(fileName, 'r')
    for line in inputFile:
        line = line.strip()
        line = line.split()
        inventoryTotal += float(line[5])
        itemDescriptors = [line[1], line[2], line[3], line[4], line[5]]
        inventoryDictionary[line[0]] = itemDescriptors
        print(line)
    print(inventoryTotal)
    print(inventoryDictionary)
    return(inventoryDictionary, inventoryTotal)

printFile = printFile()
inventoryTotal = printFile[1]
inventoryDictionary = printFile[0]
print(inventoryTotal)
print(inventoryDictionary)
