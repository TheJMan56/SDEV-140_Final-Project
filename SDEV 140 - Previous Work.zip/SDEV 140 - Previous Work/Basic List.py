inventoryDictionary = {}
totalInventoryValue = 0
itemList = open("integers.txt", 'w')

while True:
    inventoryDescriptors = []
    inventoryKey = input("Please enter the key of the inventory item: ")
    if inventoryKey == "":
        break
    inventoryName = input("Please enter the name of the inventory item: ")
    inventoryDepartment = input("Please enter the department of the inventory: ")
    inventoryQuantity = float(input("Please enter the quantity of the inventory: "))
    inventoryPrice = float(input("Please enter the cost per quantity of the inventory: "))
    inventoryValue = inventoryQuantity * inventoryPrice
    inventoryDescriptors.append(inventoryName)
    inventoryDescriptors.append(inventoryDepartment)
    inventoryDescriptors.append(inventoryQuantity)
    inventoryDescriptors.append(inventoryPrice)
    inventoryDescriptors.append(inventoryValue)
    inventoryDictionary[inventoryKey] = inventoryDescriptors

print(inventoryDictionary)
sortedInventoryKeys = list(inventoryDictionary.keys())
sortedInventoryKeys.sort()

for key in sortedInventoryKeys:
    print(key, inventoryDictionary[key])

for key in sortedInventoryKeys:
    inventoryItem = []
    inventoryItem = [key] + inventoryDictionary[key]
    print(inventoryItem)
    print("%-5s%-20s%-20s%-5d%-7.2f%-20.2f" % (inventoryItem[0], inventoryItem[1], \
                                               inventoryItem[2], inventoryItem[3], \
                                               inventoryItem[4], inventoryItem[5]))
    itemList.write(str(inventoryItem[0]) + " " + \
                       str(inventoryItem[1]) + " " + \
                           str(inventoryItem[2]) + " " + \
                               str(inventoryItem[3]) + " " + \
                                   str(inventoryItem[4]) + " " + \
                                       str(inventoryItem[5]) + "\n")
    totalInventoryValue = totalInventoryValue + inventoryItem[5]
print("%-57s%-20.2f" % (" ", totalInventoryValue))

itemList.close
itemList = open("integers.txt", 'r')
items = itemList.read()

print(items)
