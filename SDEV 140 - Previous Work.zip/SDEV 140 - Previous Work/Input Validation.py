def addToFileCheck():
    """"""
    if skuEntry.get() == "":
        isValid = False
    elif nameEntry.get() == "":
        isValid = False
    elif departmentEntry.get() == "":
        isValid = False
    elif quantityEntry.get() == "":
        isValid = False
    elif priceEntry.get() == "":
        isValid = False
    elif type(skuEntry.get()) != str:
        isValid = False
    elif type(nameEntry.get()) != str:
        isValid = False
    elif type(departmentEntry.get()) != str:
        isValid = False
    elif quantityEntry.get().isdigit() == False:
        isValid = False
    elif priceEntry.get().isdigit() == False:
        isValid = False
    elif " " in skuEntry.get():
        isValid = False
    elif " " in nameEntry.get():
        isValid = False
    elif " " in departmentEntry.get():
        isValid = False
    elif " " in quantityEntry.get():
        isValid = False
    elif " " in priceEntry.get():
        isValid = False
    elif len(skuEntry.get()) != 4:
        isValid = False
    elif len(nameEntry.get()) > 13:
        isValid = False
    elif len(departmentEntry.get()) > 13:
        isValid = False
    elif len(quantityEntry.get()) > 15:
        isValid = False
    elif len(priceEntry.get()) > 15:
        isValid = False
    else:
        isValid = True

    if isValid = False:
        outputInventory.insert(tk.END, "Invalid input\n"\
                               "All inventory input fields must be filled\n" + \
                               "Inventory input must contain zero spaces\n" + \
                               "SKU must contain four characters\n" + \
                               "Name must be ten characters or fewer\n" + \
                               "Department must be ten characters or fewer\n" + \
                               "Quantity must be digits only\n" + \
                               "Quantity must be ten digits or fewer\n" + \
                               "Price must be digits only\n" + \
                               "Price must be ten digits or fewer\n" + "\n")
    else:
        addToFile()
