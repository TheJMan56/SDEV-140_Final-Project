from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk

window = tk.Tk()

try:
    newFileImage = Image.open("New_File.png")
    render = ImageTk.PhotoImage(newFileImage)
    button = tk.Button(window, image=render, text="New File", compound="top")
    button.pack()
except:
    button = tk.Button(window, text="*New File Icon*\nNew File")
    button.pack()

window.mainloop()
